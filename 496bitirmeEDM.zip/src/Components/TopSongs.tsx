import { Stack, Button, Title } from '@mantine/core';

export default function TopSongs() {
  return (

        <Stack
          h={308}
          bg="var(--mantine-color-body)"
    
        >
          {/* <Title color='white'>En Popüler Şarkılar</Title> 
          <Button variant="default"></Button>
          <Button variant="default"></Button>
          <Button variant="default"></Button>
          <Button variant="default"></Button>
          <Button variant="default"></Button> */}
        </Stack>
  );
}
