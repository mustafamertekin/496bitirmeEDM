import { Stack, Button } from '@mantine/core';
export default function Results() {
  return (
    <Stack
    style={{border: '1px solid white', padding: '5px'}}
      h={508}
      bg="var(--mantine-color-body)"

    >
      {/* <Button variant="default">RESULT 1</Button>
      <Button variant="default">RESULT 2</Button>
      <Button variant="default">RESULT 3</Button>
      <Button variant="default">RESULT 4</Button>
      <Button variant="default">RESULT 5</Button>
      <Button variant="default">RESULT 6</Button>
      <Button variant="default">RESULT 7</Button>
      <Button variant="default">RESULT 8</Button>
      <Button variant="default">RESULT 9</Button>
      <Button variant="default">RESULT 10</Button> */}

    </Stack>
  );
}